import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { Routes, RouterModule } from '@angular/router';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { NewFormComponent } from './new-form/new-form.component';
import { ViewFormComponent } from './view-form/view-form.component';
import { FormService } from './form.service';
import { GenerateFormComponent } from './generate-form/generate-form.component';
import { EditFormComponent } from './edit-form/edit-form.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { LoadingComponentComponent } from './loading-component/loading-component.component';

const appRoutes: Routes = [
  {path: '', component: DashboardComponent},
  {path: 'dashboard', component: DashboardComponent},
  {path: 'newForm', component: NewFormComponent},
  {path: 'viewForm/:id', component: ViewFormComponent},
  {path: 'generateForm/:id', component: GenerateFormComponent},
  {path: 'editForm/:id', component: EditFormComponent},
  {path: 'not-found', component: PageNotFoundComponent},
  {path: '**', redirectTo: '/not-found'}
];


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    DashboardComponent,
    NewFormComponent,
    ViewFormComponent,
    GenerateFormComponent,
    EditFormComponent,
    PageNotFoundComponent,
    LoadingComponentComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    MatCardModule,
    ReactiveFormsModule,
    RouterModule.forRoot(appRoutes),
    HttpClientModule,
    MatIconModule,
    MatButtonModule,
  ],
  providers: [FormService],
  bootstrap: [AppComponent]
})
export class AppModule { }
