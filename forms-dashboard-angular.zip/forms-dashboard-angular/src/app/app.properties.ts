export const properties = {
  ID: 'id',
};
