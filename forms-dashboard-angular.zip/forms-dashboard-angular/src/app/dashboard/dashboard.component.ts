import { Component, OnInit } from '@angular/core';

import { FormService } from '../form.service';
import { FormStructure } from '../form.model';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit {
  forms: Array<FormStructure> = [];
  error: string;
  errorCode: string;
  isloading: boolean;

  constructor(private formservice: FormService) {}
  ngOnInit() {
    // Upon rendering this component I am subscribing to a observable which is returned by forms Service.
    // This asycn call returns all the forms that are present in the MongoDB to be rendered in the dashboard page.
    this.isloading = true;
    this.formservice.returnAllForm().subscribe(
      (form) => {
        this.forms = form;
        this.formservice.allforms = form;
        this.isloading = false;
      },
      (error) => {
        if (error.error.errorMessage) {
          this.error = error.error.errorMessage;
          this.errorCode = error.error.errorCode;
        } else {
          this.error = error.message;
          this.errorCode = error.status;
        }
        this.isloading = false;
        console.log(error);
      }
    );
  }
}
