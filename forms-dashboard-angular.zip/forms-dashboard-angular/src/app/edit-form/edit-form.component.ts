import { Component, OnInit } from '@angular/core';
import { FormService } from '../form.service';
import { FormStructure } from '../form.model';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormControl, FormArray, Validators } from '@angular/forms';
import { FormField } from '../formFields.model';
import { properties } from '../app.properties';

@Component({
  selector: 'app-edit-form',
  templateUrl: './edit-form.component.html',
  styleUrls: ['./edit-form.component.css'],
})
export class EditFormComponent implements OnInit {
  form: FormStructure;
  formfields: Array<FormField> = [];
  formfield: FormField;
  date: Date;
  isvalid: boolean;
  id: string;
  alert = false;
  errorCode: string;
  currentForm: FormStructure;
  editForm: FormGroup;
  currentformfield: FormGroup;
  error: string;
  isloading: boolean;
  constructor(
    private formservice: FormService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    // On rendering this component, I am getting the current form from "allforms" variable in the forms Service.
    // upon getting the form details, I am initializing the form with the current details, so that it can be edited.
    this.id = this.route.snapshot.params[properties.ID];
    for (
      var formsiterator = 0;
      formsiterator < this.formservice.allforms.length;
      formsiterator++
    ) {
      if (this.formservice.allforms[formsiterator].id === this.id) {
        this.currentForm = this.formservice.allforms[formsiterator];
      }
    }
    this.editForm = new FormGroup({
      formTitle: new FormControl(this.currentForm.formTitle, [
        Validators.required,
        Validators.maxLength(30),
        Validators.pattern('[a-zA-Z ]*'),
      ]),
      formDescription: new FormControl(this.currentForm.formDescription, [
        Validators.required,
        Validators.maxLength(150),
        Validators.pattern('[a-zA-Z0-9. ]*'),
      ]),
      formFields: new FormArray([]),
    });
    for (
      var formfielditerator = 0;
      formfielditerator < this.currentForm.formFields.length;
      formfielditerator++
    ) {
      const feildgroup = new FormGroup({
        controlLabel: new FormControl(
          this.currentForm.formFields[formfielditerator].controlLabel,
          Validators.required
        ),
        controlType: new FormControl(
          this.currentForm.formFields[formfielditerator].controlType,
          Validators.required
        ),
        mandatory: new FormControl(
          this.currentForm.formFields[formfielditerator].mandatory,
          Validators.required
        ),
        associatedValues: new FormControl(
          this.currentForm.formFields[formfielditerator].associatedValues
        ),
      });
      (this.editForm.get('formFields') as FormArray).push(feildgroup);
    }
  }

  onAddFormFields() {
    // This function will add a new field in the UI for the user to add another form field.
    const feildgroup = new FormGroup({
      controlLabel: new FormControl(null, [Validators.required]),
      controlType: new FormControl(null, [Validators.required]),
      mandatory: new FormControl(null, Validators.required),
      associatedValues: new FormControl(null),
    });
    (this.editForm.get('formFields') as FormArray).push(feildgroup);
  }

  onDelete(index: number) {
    //This function will delete a particular form field.
    const FormFields = 'formFields';
    const arrayControl = this.editForm.controls[FormFields] as FormArray;
    arrayControl.removeAt(index);
  }

  resetForm() {
    // This function will reset the current form.
    this.editForm.reset();
  }

  moveUp(index: number) {
    // This function will move up the current form field in the forms fields array.
    const CONTROLS = 'controls';
    if (index !== 0) {
      this.currentformfield = new FormGroup({});
      this.currentformfield = this.editForm[CONTROLS].formFields[CONTROLS][
        index
      ];
      this.editForm[CONTROLS].formFields[CONTROLS][index] = this.editForm[
        CONTROLS
      ].formFields[CONTROLS][index - 1];
      this.editForm[CONTROLS].formFields[CONTROLS][
        index - 1
      ] = this.currentformfield;
    }
  }

  moveDown(index: number) {
    // This function will move down the current form field in the forms fields array.
    const CONTROLS = 'controls';
    if (index !== this.editForm[CONTROLS].formFields[CONTROLS].length) {
      this.currentformfield = new FormGroup({});
      this.currentformfield = this.editForm[CONTROLS].formFields[CONTROLS][
        index
      ];
      this.editForm[CONTROLS].formFields[CONTROLS][index] = this.editForm[
        CONTROLS
      ].formFields[CONTROLS][index + 1];
      this.editForm[CONTROLS].formFields[CONTROLS][
        index + 1
      ] = this.currentformfield;
    }
  }
  onSubmit() {
    // This function will submit the current edited form.
    //Upon submiting it will call the webservice to update the form in the MongoDB
    if (this.editForm.valid) {
      this.isvalid = true;
      this.alert = false;
    } else {
      this.isvalid = false;
      this.alert = true;
      return;
    }
    this.isloading = true;
    this.date = new Date();
    const CONTROLS = 'controls';
    for (
      var formfieldsiterator = 0;
      formfieldsiterator < this.editForm.value.formFields.length;
      formfieldsiterator++
    ) {
      this.formfield = new FormField(
        this.editForm[CONTROLS].formFields[CONTROLS][
          formfieldsiterator
        ].value.controlLabel,
        this.editForm[CONTROLS].formFields[CONTROLS][
          formfieldsiterator
        ].value.controlType,
        this.editForm[CONTROLS].formFields[CONTROLS][
          formfieldsiterator
        ].value.mandatory,
        this.editForm[CONTROLS].formFields[CONTROLS][
          formfieldsiterator
        ].value.associatedValues
      );
      this.formfields.push(this.formfield);
    }
    this.form = new FormStructure(
      this.editForm.value.formTitle,
      this.editForm.value.formDescription,
      this.date,
      this.formfields
    );
    this.formservice.updateForm(this.form, this.id).subscribe(
      (respondata) => {
        this.formfields = [];
        this.isloading = false;
        this.router.navigate(['/dashboard']);
      },
      (error) => {
        this.isloading = false;
        if (error.error.errorMessage) {
          this.error = error.error.errorMessage;
          this.errorCode = error.error.errorCode;
        } else {
          this.error = error.message;
          this.errorCode = error.status;
        }
      }
    );
  }
  closeAlert() {
    // This function will close the alert that comes up when you try to submit invalid form.
    this.alert = false;
  }
}
