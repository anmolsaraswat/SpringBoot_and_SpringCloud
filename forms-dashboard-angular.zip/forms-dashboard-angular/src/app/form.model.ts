import { FormField } from './formFields.model';

export class FormStructure {
  public id?: string;
  public formTitle: string;
  public formDescription: string;
  public lastUpdatedDate: Date;
  public formFields: Array<FormField>;

  constructor(
    title: string,
    desc: string,
    date: Date,
    formFields: Array<FormField>
  ) {
    this.formTitle = title;
    this.formDescription = desc;
    this.lastUpdatedDate = date;
    this.formFields = formFields;
  }
}
