import { FormStructure } from './form.model';
import { Subject } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../environments/environment';

@Injectable()
export class FormService {
  i: number;
  constructor(private http: HttpClient) {}
  formChanged = new Subject<FormStructure[]>();
  currentForm: FormStructure;
  allforms: Array<FormStructure> = [];

  addForm(form: FormStructure) {
    return this.http.post(environment.addNewForm, form);
  }
  returnAllForm() {
    return this.http.get<Array<FormStructure>>(environment.getAllForms);
  }
  deleteForm(id: string) {
    return this.http.delete(environment.deleteForm + id);
  }
  updateForm(form: FormStructure, id: string) {
    return this.http.put<FormStructure>(environment.editForm + id, form);
  }
}
