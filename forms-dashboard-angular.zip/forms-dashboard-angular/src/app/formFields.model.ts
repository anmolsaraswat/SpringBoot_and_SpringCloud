export class FormField{
    public controlLabel: string;
    public controlType: string;
    public mandatory: string;
    public associatedValues: string;

    constructor(label: string, type: string, mandatory: string, associatedValue: string){
        this.controlLabel = label;
        this.controlType = type;
        this.mandatory = mandatory;
        this.associatedValues = associatedValue;
    }
}
