import { Component, OnInit } from '@angular/core';
import { FormService } from '../form.service';
import { FormStructure } from '../form.model';
import { ActivatedRoute } from '@angular/router';
import { properties } from '../app.properties';

@Component({
  selector: 'app-generate-form',
  templateUrl: './generate-form.component.html',
  styleUrls: ['./generate-form.component.css'],
})
export class GenerateFormComponent implements OnInit {
  id: string;
  currentForm: FormStructure;
  AssociatedValues: Array<Array<string>> = [];
  emptyArray: Array<string> = [];
  error = null;
  constructor(
    private route: ActivatedRoute,
    private formservice: FormService
  ) {}

  ngOnInit(): void {
    // Upon rendering this component, I am fetching the current form from the forms service.
    // And I am creating a array of associated values from the details to be rendered on the UI.
    this.id = this.route.snapshot.params[properties.ID];
    this.currentForm = this.formservice.currentForm;
    for (
      var formfieldsiterator = 0;
      formfieldsiterator < this.currentForm.formFields.length;
      formfieldsiterator++
    ) {
      if (!this.currentForm.formFields[formfieldsiterator].associatedValues) {
        this.AssociatedValues.push(this.emptyArray);
      } else {
        this.AssociatedValues.push(
          this.currentForm.formFields[
            formfieldsiterator
          ].associatedValues.split('|')
        );
      }
    }
  }
}
