import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loading-component',
  template:
    '<div class = "lds-ring"><div></div><div></div><div></div><div></div></div>',
  styleUrls: ['./loading-component.component.css'],
})
export class LoadingComponentComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
