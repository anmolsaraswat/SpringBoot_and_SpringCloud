import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormArray } from '@angular/forms';

import { FormStructure } from '../form.model';
import { FormField } from '../formFields.model';
import { FormService } from '../form.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-new-form',
  templateUrl: './new-form.component.html',
  styleUrls: ['./new-form.component.css'],
})
export class NewFormComponent implements OnInit {
  form: FormStructure;
  formfields: Array<FormField> = [];
  formfield: FormField;
  date: Date;
  alert = false;
  errorCode: string;
  newForm: FormGroup;
  currentformfield: FormGroup;
  error: string;
  isvalid: boolean;
  isloading: boolean;
  constructor(private formservice: FormService, private router: Router) {}

  ngOnInit() {
    // Upon rendering this component I am initializing a new form using reactive approach.
    this.newForm = new FormGroup({
      formTitle: new FormControl(null, [
        Validators.required,
        Validators.maxLength(30),
        Validators.pattern('[a-zA-Z ]*'),
      ]),
      formDescription: new FormControl(null, [
        Validators.required,
        Validators.maxLength(150),
        Validators.pattern('[a-zA-Z0-9. ]*'),
      ]),
      formFields: new FormArray([]),
    });
  }

  onAddFormFields() {
    // This function will add a new form field in the form and UI.
    const feildgroup = new FormGroup({
      controlLabel: new FormControl(null, Validators.required),
      controlType: new FormControl(null, Validators.required),
      mandatory: new FormControl(null, Validators.required),
      associatedValues: new FormControl(null),
    });
    (this.newForm.get('formFields') as FormArray).push(feildgroup);
  }

  onSubmit() {
    // This function will submit the form if the form is valid.
    // It will call a webservice will will add a new form in the MongoDB.
    if (this.newForm.valid) {
      this.isvalid = true;
      this.alert = false;
    } else {
      this.isvalid = false;
      this.alert = true;
      return;
    }
    this.isloading = true;
    const Controls = 'controls';
    this.date = new Date();
    for (
      var formfielditerator = 0;
      formfielditerator < this.newForm.value.formFields.length;
      formfielditerator++
    ) {
      this.formfield = new FormField(
        this.newForm[Controls].formFields[Controls][
          formfielditerator
        ].value.controlLabel,
        this.newForm[Controls].formFields[Controls][
          formfielditerator
        ].value.controlType,
        this.newForm[Controls].formFields[Controls][
          formfielditerator
        ].value.mandatory,
        this.newForm[Controls].formFields[Controls][
          formfielditerator
        ].value.associatedValues
      );
      this.formfields.push(this.formfield);
    }
    this.form = new FormStructure(
      this.newForm.value.formTitle,
      this.newForm.value.formDescription,
      this.date,
      this.formfields
    );
    this.formservice.addForm(this.form).subscribe(
      (responseData) => {
        this.formfields = [];
        this.newForm.reset();
        this.isloading = false;
        this.router.navigate(['/dashboard']);
      },
      (error) => {
        this.isloading = false;
        if (error.error.errorMessage) {
          this.error = error.error.errorMessage;
          this.errorCode = error.error.errorCode;
        } else {
          this.error = error.message;
          this.errorCode = error.status;
        }
      }
    );
  }

  onDelete(index: number) {
    // This function will detele a particular form field from the form.
    const FormFields = 'formFields';
    const arrayControl = this.newForm.controls[FormFields] as FormArray;
    arrayControl.removeAt(index);
  }

  resetForm() {
    // This function will reset the form.
    this.newForm.reset();
  }

  moveUp(index: number) {
    // This function will move up the current form field in the forms fields array.
    const Controls = 'controls';
    if (index !== 0) {
      this.currentformfield = new FormGroup({});
      this.currentformfield = this.newForm[Controls].formFields[Controls][
        index
      ];
      this.newForm[Controls].formFields[Controls][index] = this.newForm[
        Controls
      ].formFields[Controls][index - 1];
      this.newForm[Controls].formFields[Controls][
        index - 1
      ] = this.currentformfield;
    }
  }
  moveDown(index: number) {
    // This function will move down the current form field in the forms fields array.
    const Controls = 'controls';
    if (index !== this.newForm[Controls].formFields[Controls].length) {
      this.currentformfield = new FormGroup({});
      this.currentformfield = this.newForm[Controls].formFields[Controls][
        index
      ];
      this.newForm[Controls].formFields[Controls][index] = this.newForm[
        Controls
      ].formFields[Controls][index + 1];
      this.newForm[Controls].formFields[Controls][
        index + 1
      ] = this.currentformfield;
    }
  }
  closeAlert() {
    // This function will close the alert that comes up when you try to submit invalid form.
    this.alert = false;
  }
}
