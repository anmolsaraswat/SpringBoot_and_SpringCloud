import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormStructure } from '../form.model';
import { FormService } from '../form.service';
import { properties } from '../app.properties';

@Component({
  selector: 'app-view-form',
  templateUrl: './view-form.component.html',
  styleUrls: ['./view-form.component.css'],
})
export class ViewFormComponent implements OnInit {
  id: string;
  currentForm: FormStructure;
  error: string;
  errorCode: string;
  isloading: boolean;
  constructor(
    private route: ActivatedRoute,
    private formservice: FormService,
    private router: Router
  ) {}

  ngOnInit(): void {
    // Upon rendering this component I am getting the current form from the forms service to be displayed on the UI.
    this.id = this.route.snapshot.params[properties.ID];
    for (
      var formsiterator = 0;
      formsiterator < this.formservice.allforms.length;
      formsiterator++
    ) {
      if (this.formservice.allforms[formsiterator].id === this.id) {
        this.currentForm = this.formservice.allforms[formsiterator];
        this.formservice.currentForm = this.currentForm;
      }
    }
  }
  deleteForm(id: string) {
    // This function will delete the current form from the MongoDB.
    this.isloading = true;
    this.formservice.deleteForm(id).subscribe(
      (res) => {
        this.isloading = false;
        this.router.navigate(['/dashboard']);
      },
      (error) => {
        this.isloading = false;
        if (error.error.errorMessage) {
          this.error = error.error.errorMessage;
          this.errorCode = error.error.errorCode;
        } else {
          this.error = error.message;
          this.errorCode = error.status;
        }
        console.log(error);
      }
    );
  }
}
