package com.deloitte.formsdashboardcouldgateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.CrossOrigin;

@SpringBootApplication
public class FormsDashboardCloudGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(FormsDashboardCloudGatewayApplication.class, args);
	}

}
